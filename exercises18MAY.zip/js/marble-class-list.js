'use-strict';

let marbles = document.getElementsByClassName('marble');

marbles[0].classList.add('rounded');
marbles[1].classList.add('orange','size_x');
marbles[2].classList.add('incline','size_xx');
marbles[3].classList.add('rounded','purple','offset');
marbles[4].classList.add('rounded','size_xxx','purple');